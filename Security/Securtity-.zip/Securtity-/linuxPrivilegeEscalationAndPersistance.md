## Security Day 9 *(Jan 12, 2022)* **(Linux Privilege Escalation,Persistence & Covering Tracks)**

### Exploit Development

[Linux Privilege Escalation,Persistence & Covering Tracks Slides](https://sec.cybbh.io/-/public/-/jobs/643395/artifacts/slides/10-linux-priv-persist-cover.html)

[Linux Privilege Escalation,Persistence & Covering Tracks Field Guide](https://sec.cybbh.io/public/security/latest/lessons/lesson-10-linux-exploit_sg.html)

[LinPeas Privilege Escalation](https://github.com/carlospolop/PEASS-ng/tree/master/linPEAS)

---
### Today's plan

  - [X] Linux Privilege Escalation,Persistence & Covering Tracks Slides
  - [X] CTF's

---

#### Rationale

Privilege escalation and maintaining persistence are among the many post-exploitation skills and tasks that attackers must grasp. Attackers and defenders need to understand how privilege escalation can occur and how persistence can be maintained on a system. This understanding allows attackers to move freely through a network, and allows defenders to prevent privilege escalation, detect attacker movement, and detect/prevent attacker persistence mechanisms.

### Objectives
Establish and Maintain Linux Persistence by:

Adding or hijacking a User Account

Implementing Boot Process Persistence

Adding or Modifying a Cron Job

Adding a Kernel Module with a Backdoor

And other methods outside the FG …​

#### Discuss …​
What is privilege escalation?

What privs do you want and why?

What are some considerations of privilege escalation?

If I obtained privs as user "bob", if I can obtain privs for user "jane", is that escalation?

#### Enumeration For Privilege Escalation

* What are your techniques and processes?
  - Any particular order?
  - Anything else you should be doing while on the box?

#### Physical Discussion/Demonstration

If you have the physical box you own it. Put the hard drive in different machine to open it.

#### Sudo

* What is sudo?
* Why consider it for privilege escalation?
* What commands do you run?

#### Sudo Gotchas

* Commands that can access the contents of other files
* Commands that download files
* Commands that execute other commands (i.e. editors)
* Dangerous commands

**Sources**

* https://linux.die.net/man/5/sudoers - sudoers manpage
* https://wiki.archlinux.org/index.php/sudo#Configuration - sudo configuration
* https://www.tecmint.com/10-most-dangerous-commands-you-should-never-execute-on-linux/ - Dangerous commands
* https://gtfobins.github.io/gtfobins/tcpdump/ - **GTFO Bins**

#### Sudo Demonstration

```
sudo cat /etc/sudoers
sudo

sudo find . -exec /bin/sh \; -quit # become root ## USE GTFO
```

#### SUID/SGID

* What is SUID/SGID?
* Why consider it for privilege escalation?
* What commands do you run?

#### Capabilities

* What are capabilities?
* Why consider it for privilege escalation?
* What commands do you run?

#### SUID/SGID Demonstration

```
find / -type f -perm /4000 -ls 2>/dev/null # Find SUID only files
find / -type f -perm /2000 -ls 2>/dev/null # Find SGID only files
find / -type f -perm /6000 -ls 2>/dev/null # Find SUID and/or SGID files
# then look to see if anything pulled up shows in gtfobins
strings /bin/netstat_natpu | grep netstat # SHows what is being executed on the command line when netstat_natpu is being ran
```

#### Insecure Permissions

* Cron
* Word Writable Files and Directories
* Dot '.' in the Path

#### Cron

* What is cron?
* Why consider it for privilege escalation?
* What commands do you run?

#### World Writable Files and Folders

* Why consider it for privilege escalation?
* What commands do you run?

#### DOT '.' In The Path

* Why consider it for privilege escalation?
* What commands do you run?/

#### World Writable Files and Folders/Dot '.' In The Path Demonstration

```
tmp
find / -type d -perm /2 -ls 2>/dev/null #
```

#### Vulnerable Software and Services

* Why consider it for privilege escalation?
* What commands do you run?

#### Unpatched Kernel Vulnerabilities

* Why consider it for privilege escalation?
* What commands do you run?

#### Objectives

* Methods to Maintain Linux Persistence
  - Add or Hijack User Account
  - Implement Boot Process Persistence
  - Add or Modify Cron jobs
  - Implement Kernel Modules with Backdoors
  - And other methods outside the FG …​

#### Discuss

* What is persistence?
* What is the purpose of persistence?
* What are some considerations of obtaining or utilizing persistence?
* Does persistence mean I have immediate access to the target?

#### Adding or Hijacking A User Account

* Adding vs Hijacking
* User account considerations?
* How do you access it?

#### User Account Discussion/Demonstration


#### Boot Process Persistence

* Where and how do you implement?
* Why consider it for persistence?
* How do you access it?

#### Boot Process Persistence Demonstration


#### Cron Job

* System vs User Cron
* Why consider it for persistence?
* How do you access it?

#### Cron Persistence Demonstration

```
cat /etc/crontab
crontab -l
crontab -e
```
[Reverse Shell Generator](https://www.revshells.com/)

use nc.exe -e and then put that line in new terminal. input listener ip and port #

set up listener nc -lnvp 'port number'

look up how to make a dumb shell a smart shell

#### Kernel Module Backdoor

* Why consider it for persistence?
* How do you access it?

#### Kernel Module Persistence Demonstration


#### Discuss Other Methods


#### Covering Tracks

#### Objectives

* Familiarization with OS auditing and logging
* Perform log cleaning and blending in
* Identify aritfacts

#### Plan

* Prior, after, before == know the system
  - What will happen if I do X == logs
  - Checks == where are things
  - Hide == file locations, names, times
* When does Covering Tracks start?

#### Artifacts

* What are they?
  - Things left behind like object file compiled in c for example.

#### System Usage

* Where to work from on the remote system? Why?
* Are system resources a important?

#### NIX-ISM

* First thing: unset HISTFILE
* Need to be aware of what type of sysinit
  - SystemV, upstart, systemd to name a few
  - Determines what commands in use and logging structure.

#### Ways To Figure Init Type

```
ls -latr /proc/1/exe
stat /sbin/init
man init
init --version
ps 1
```

#### Auditing Systemv

* ausearch -→ pulls from audit.log

```
ausearch -p 22
ausearch -m USER_LOGIN -sv no
ausearch -ua edwards -ts yesterday -te now -i
```

#### Systemd

* Utilizes journalctl

```
journalctl _TRANSPORT=audit
journalctl _TRANSPORT=audit | grep 603
```

#### Logs For Covering Tracks

* Logs typically housed in /var/log, some useful logs:
  - lastlog --- each users successful login time
  - btmp --- tracks bad login attempts
  - secure --- Syslog
  - sulog --- use of su command
  - utmp --- users currently on (w)
  - wtmp --- permanent record on user on/off
  - auth.log/secure --- tracks usage of authorization <- will use for ctf

#### Working With Logs

```
file /var/log/wtmp
find /var/log -type f -mmin -10 2> /dev/null
journalctl -f -u ssh
journalctl -q SYSLOG_FACILITY=10 SYSLOG_FACILITY=4
```

#### Reading Files

```
cat /var/log/auth.log | egrep -v "opened|closed"
awk '/opened/' /var/log/auth.log
last OR lastb OR lastlog
strings OR dd (for data files)
more /var/log/syslog
head/tail
```

* Control your output with piping and more

#### Cleaning The Tools

* Before we start cleaning, save the inodes
* Difference between mv, cp, cat
* Know what we are removing (entry times, IP, whole file, etc)

#### Cleaning The Logs, Basic

* Just get rid of it

```
rm -rf (/path/file)
```

* Blank It

```
cat /dev/null > (/path/file)
echo > /var/log/btmp
```

#### Cleaning The Logs, Percision

* Always work off a backup

```
egrep -v '10:49*| 15:15:15' auth.log > auth.log2; cat auth.log2 > auth.log; rm auth.log2 +
cp auth.log > auth.log2; sed -i 's/10.16.10.93/136.132.1.1/g' auth.log2; cat auth.log2 > aut0
```

#### Clean - Your Turn

1. Create a failed ssh log on your RE_Linux.
2. Utilizing the command line clean the log of the assocated log entries of the failed ssh event.
3. Maintain log files orignal Inode

#### TimeStomp Nix

* Access: updated when opened or used (grep, ls, cat, etc)
* Modify: update content of file or saved
* Change: file attribute change, file modified, moved, owner, permission

#### Timestomp Nix

* Easy with Nix vs Windows, native change of Access & Modify times

```
touch -c -t 201603051015 1.txt
touch -r 3.txt 1.txt
```
* NOTE: Change time requires changing the system time than touch the file. Could cause serious issues

#### Logging Remote

* Good or bad, maybe both?

#### Logging Remote

* Have to check the config
  - Identify Server
  - Identify what logs are shipped off
* Rsyslog, need to be careful - newer version calls different location for rules

#### RYSLOG

* Newer Rsyslog call /etc/rsyslog.d/* for settings/rules
* Older uses /etc/rsyslog.conf
* To find out:
  - grep "IncludeConfig" /etc/rsyslog.conf

[RSYSLOG Wiki](https://wiki.gentoo.org/wiki/Rsyslog)
[RSYSLOG Info](https://www.the-art-of-web.com/system/rsyslog-config/)

#### Reading Rsyslog

* Utilizes severity(priority) and facility levels
* rule is a filter, can use keyword or number

```
<facility>.<priority>
```

#### RSYSLOG Examples

```
kern.*
mail.crit
cron.!info,!debug
*. *  @192.168.10.254:514
#mail.*
```

#### CTFD and Hide In Plain Sight

* Hide in plain sight
  - Get ncat onto the RE_Windows box.(http://nmap.org/dist/ncat-portable-5.59BETA1.zip)
  - Configure ncat as a service on your system and evade detection.
  - Once complete, let the me.


#### Password Cracking

John The Ripper

Will need passwd and shadow file and scp to op station

```
john --wordlist=10mil.txt shadow.txt # shadow.txt is the shadow file
ex. john --wordlist=passwordlist.txt hashetc
.txt
john --show shadow.txt

```
