## Security Day 10 *(Jan 13, 2022)* **(Windows Privilege Escalation & Persistence)**

### Exploit Development

[Windows Privilege Escalation & Persistence Slides ](https://sec.cybbh.io/-/public/-/jobs/643395/artifacts/slides/09-windows-priv-persist-cover.html)

[Windows Privilege Escalation & Persistence Field Guide](https://sec.cybbh.io/public/security/latest/lessons/lesson-9-windows-exploit_sg.html)

---
### Today's plan

  - [X] Windows Privilege Escalation & Persistence Slides
  - [X] CTF's

---

#### Rationale

Privilege escalation and maintaining persistence are among the many post-exploitation skills and tasks that attackers must grasp. Attackers and defenders need to understand how privilege escalation can occur and how persistence can be maintained on a system. This understanding allows attackers to move freely through a network, and allows defenders to prevent privilege escalation, detect attacker movement, and detect/prevent attacker persistence mechanisms.

#### Modes & Levels

Kernel Mode vs. User Mode

Privileged vs. Unprivileged

#### Windows Access Control Model

* Access Tokens:
`Security Identifier (SID) associations and Token associations`
* Security Descriptors:
  - DACL
  - SACL
  - ACEs
  * *We will learn DLL hijacking today*

#### DLL Search Order

Executables check the following locations:
* HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\KnownDLLs
* The directory the the Application was run from
* The directory specified in in the C+ function GetSystemDirectory()
* The directory specified in the C+ function GetWindowsDirectory()
* The current directory

#### Windows Integrity Mechanism

Integrity Levels

* Untrusted - Anonymous SID access tokens
* Low - Everyone SID access token (World)
* Medium - Authenticated Users
* High - Administrators
* System - System services (LocalSystem, LocalService, NetworkService)

#### User Account Control (UAC)

* Always Notify
* Notify me only when programs try to make changes to my computer
* Notify me only when programs try to make changes to my computer (do not dim my desktop)
* Never notify

#### Demo Checking UAC Settings

`reg query HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System`

#### Autoelevate Executables

Requested Execution Levels
* asInvoker
* highestAvailable

#### Privilege Escalation

*Actions that allows an adversary to obtain a higher level of permissions on a system or network.*

#### Scheduled Tasks & Services

Items to evaluate include:
* Write Permissions
* Non-Standard Locations
* Unquoted Executable Paths
* Vulnerabilities in Executables
* Permissions to Run As SYSTEM
  - Learn to exploit user created services

#### Demo: Finding Vulnerable Scheduled Tasks

`schtasks /query /fo LIST /v`

#### Demo: DLL Hijacking

* Identify Vulnerability
* Take advantage of the default search order for Dll
* NAME_NOT_FOUND present in executables system calls
* Validate permissions
* Create and transfer Malicious Dll

#### Demo Finding Vulnerable Services

`wmic service list full`

```
ps C:\ program file> icacls "filename"

# have to restart system to get a service you put on the box to run. Also make sure service is set to automatic
# task scheduler, click on test app
```

```
procmon
apply filter for file by name, path has .dll and result contains Name not found

sudo apt-get install mingw-w64 mingw-w64-common mingw-w64-i686-dev mingw-w64-tools mingw-w64-tools mingw-w64-x86-64-dev -y

i686-w64-mingw32-g++ -c bad.c -o bad.o

i686-w64-mingw32-g++ -shared -o bad.dll bad.o -Wl,--out-implib,bad.a
```
#### Demo Vulnerable Services

* Identify Vulnerability
* Validate permissionssc
* Validate Executable Paths
* Replace with Malicious File

#### Other Vulnerabilities

* Unpatched Kernel Vulnerabilities
* Unpatched Systems
* Unpatched Applications


#### Demo: System Access and Defeating Protections

The objective of this is to provide yourself unrestricted access to a system, and identify methods to execute malicious activity through a basic command line prompt.

* Sysinternals
* Schedule Task
* UAC Bypass

#### Persistence

System changes or binary uploads that provide adversary continued access to system.

Survives:

`Reboots, Credential changes, DHCP IP reassignment, Etc.`

* Considerations include:
  - File naming
  - File location
  - Timestomping
  - Port selection

#### Registry

`HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\`
* Run
* RunOnce

`HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\```

* Run
* RunOnce

#### Scheduled Tasks

Permission Levels Considerations

What is your objective?

Do you need to blend in?

#### Services

At Startup

Perform Multiple Functions

Typically require Administrative Access


#### Covering Tracks

When does planning start?

* Prior, after, before == know the system
  - What will happen if I do X == logs
  - Checks == where are things
  - Hide == file locations, names, times

#### Considerations

* Artifacts
  - Determine which events will create a log
  - Event logging: Applications, SecuriG5xvVjwhqFWdbzSty, Setup, System
* Blending In
* TimeStomping

#### System Usage

Where should you run commands from?

* Locally
* Remotely

Are system resources a important, and how can we check them?

`wmic, net, netstat`

#### Demo Audit Logging

* Shows all audit category setting

Have to be admin to run these commands 

`auditpol /get /category:*`

* What does the below command show?

`auditpol /get /category:* | findstr /i "success failure"`

#### Microsoft Event IDS (Some Important Ones)

* 4624/4625 successful/failed login
* 4720 account created
* 4672 administrator equivalent user logs on
* 7045 Service creation

#### Demo: Event Logging

```
Storage: c:\windows\system32\config\ FileType: .evtx/.evt
wevtutil el
wmic ntevent where "logfile="<LOGNAME>" list full
Get-Eventlog -List
```

#### Powershell Logging

* Windows CLI CMD history is per instance (doskey /history)
* Powershell can be set to log sessions
  - 2.0 little evidence == nothing about what was executed
  - 3.0 Module logging (EventID 4103)
  - 4.0 Module logging
  - 5.0 Can set module, script block (EvnetID 4104) and transcription

#### Demo Additional Logging

* Determine PS version (bunch of ways)

```
reg query hklm\software\microsoft\powershell\3\powershellengine\

powershell -command "$psversiontable"
```

* Determine if logging is set (PowerShell and WMIC)

```
eg query [hklm or hkcu]\software\policies\microsoft\windows\powershell

reg query hklm\software\microsoft\wbem\cimom \| findstr /i logging
    # 0 = no | 1 = errors | 2 = verbose
```
* WMIC Log Storage

```
%systemroot%\system32\wbem\Logs\``
```

#### Demo: Manipulation Logs and Files

* Find FIles and Alter File attributes:

```
forfiles /P c:\windows\system32 /S /D +05/14/2019

wmic datafile where name='c:\\windows\\system32\\notepad.exe' get CreationDate, LastAccessed, LastModified

copy /b filename.ext +,,

$(Get-Item file.ext).lastaccesstime=$(date) |$(Get-Item test.txt).lastaccesstime=$(Get-Date
```
* Clear Event Logs

```
wevtutil clear-log Application

Clear-Eventlog -Log Application, System
```

#### Demo: Windows Covering Tracks with Persistence

* Lets add a backdoor hidden in plain sight


#### Demo Basic
