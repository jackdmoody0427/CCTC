## Security Day 1 *(Dec 15, 2021)* **(Security Basics)**

### Class Basics

#### Links

| [CTF Security Website](http://10.50.22.9:8000/) |
---
| Login: `CHWH-005-B` |
| Password: `G5xvVjwhqFWdbzS` |
| [Field Guide](http://10.50.30.77/classinfo.html) |
---
| Pin: `257` |
| Station Number: `17` |
| Username: `CHWH-005-B` |
| Password: `G5xvVjwhqFWdbzS` |
| Lin.internet: `10.50.42.163` |

| OPS Station |
---
| User: `student` |
| Command Linux: `ssh student@10.50.25.200 -X`|
| Command Windows: `ssh student@10.50.26.239 -X`|
| Password: `password` |
| Domain: `10.50.255.254` |
| IP Linux: `10.50.25.200`  |
| IP Windows: `10.50.26.239`  |
| [URL Script](https://git.cybbh.space/CCTC/students/-/raw/master/ops_stations/cctc_ops_station.yaml) |
| 103 |


| Internet Hosts Info |
---
| User: `student_23` |
| Command: `ssh student@10.50.42.158 -X`|
| Password: `password` |
---

[VPN Config](https://git.cybbh.space/CCTC/students/-/raw/master/students/modules/ROOT/examples/config.ovpn)


CTFusername,password,pivot

CHWH-005-B | G5xvVjwhqFWdbzS | 10.50.23.43 |
