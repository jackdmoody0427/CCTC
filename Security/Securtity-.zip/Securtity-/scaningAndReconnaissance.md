## Security Day 1 *(Dec 15, 2021)* **(Security Basics)**

### Scanning and Reconnaissance

[Scanning and Reconnaissance Slides](https://sec.cybbh.io/-/public/-/jobs/579821/artifacts/slides/02-network-scanning-and-recon.html)

---
### Today's plan
  - [X] Intros
  - [X] CTFd Orientation
  - [X] Scanning and Reconnaissance Slides
  - [X] CTF's
---
#### Rationale

To properly exploit or defend a target, Cyber actors must fully understand the weaknesses in its organization, people, systems, etc. This can only be achieved with extensive information gathering through open source research, information collection, and technical fingerprinting/scanning.

#### Open Source Intelligence

* Appropriate Documentation Practices
* Use of Collected Data
* Collection Methods

#### DOD STATES:

"Produced from publicly available information that is collected, exploited, and disseminated in a timely manner to an appropriate audience for addressing a specific intelligence requirement."

#### Documantaion

Slides 5 & 6

#### Limitations on Collection
* U.S. Personel

#### Data To Collect
* Web Data
  - Cached Content, Analytics, Proxy Web Application, Command Line Interrogation
* Sensitive Data
  - Business Data, Profiles, Non-Profits/Charities, Business Filings, Historical and Public Listings
* Publicly Accessible
  - Physical Addresses, Phone Numbers, Email Addresses, User Names, Search Engine Data, Web and Traffic Cameras, Wireless Access Point Data
* Social Media
  - Twitter, Facebook, Instagram, People Searches, Registry and Wish Lists
* Domain and IP Data
  - DNS Registration, IP Address Assignments, Geolocation Data, Whois

#### Demonstration
* Data Collection through scrapping

```
python3 -m pip install requests lxml
```

```
import lxml.html
import requests

page = requests.get('http://quotes.toscrape.com')
tree = lxml.html.fromstring(page.content)

authors = tree.xpath('//small[@class="author"]/text()')

print ('Authors: ',authors)
Authors:  ['Albert Einstein', 'J.K. Rowling', 'Albert Einstein', 'Jane Austen', 'Marilyn Monroe', 'Albert Einstein', u’Andr\xe9 Gide', 'Thomas A. Edison', 'Eleanor Roosevelt', 'Steve Martin']
```

#### Advamced Scanning Techninetstat -antp | grep -i listenques
* Host Discovery
  - Find hosts that are online
* Host Enumeraation
  - Find ports for each host that is online
* Host Interrogation
  - Find what service is running on each open/available port

#### Demonstration
* Advanced Scanning Techniques

#### NMAP Scripting Engine
* Benifits of Scanning with Scripts
* Script Management and Utilization
* Usage and Examples

#### NMAP Project States
"It allows users to write (and share) simple scripts to automate a wide variety of networking tasks. Those scripts are then executed in parallel with the speed and efficiency you expect from Nmap."

#### MAIN BENIFITS
* Network Discovery
* Sophisticated Version Detection
* Vulnerability Detection
* Backdoor Detection
* Vulnerability Exploitation

#### Scrip Managenent

Scripts are stored in a subdirectory of the Nmap data directory by default: ```/usr/share/nmap/scripts```

#### Demonstration
Nmap Familiarization

````
nmap 10.50.36.201 -Pn # -Pn not ping firewall
nmap 10.50.36.201 -Pn --script banner # Banner grab
cd /usr/share/nmap/scripts # Show all the banner scripts ls with | grep
#http-enum.nse
nmap 10.50.36.201 -Pn --script banner -p 1-1000 # Ping ports in range
for i in {1..254} ;do (ping -c 1 192.168.1.$i | grep "bytes from" &) ;done # ping sweep linux
for /L %i in (1,1,255) do @ping -n 1 -w 200 192.168.1.%i > nul && echo 192.168.1.%i is up. # ping sweep windows
```

#### Usage And Examples
Scripts are stored in a subdirectory of the Nmap data directory by default

```
nmap --script <filename>|<category>|<directory>
nmap --script-help "ftp-* and discovery"
nmap --script-args <args>
nmap --script-args-file <filename>
nmap --script-help <filename>|<category>|<directory>
nmap --script-trace
```

#### Demonstration
Usage of Nmap NSE
