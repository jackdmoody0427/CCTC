## Reverse Engineering Challenges

```
Gorgas Reverse Engineering (GRE)
XX Sep 2025
Start Time: 1300
Duration: 4 hours

Type of Operation: DEVOPS

Objective: Intel has identified that the Donovian_Webserver (192.168.28.111) is hosting binaries via port 80 at the following URI /longTermStorage. We have been tasked with pulling the binaries back into blue space to conduct Reverse Enineering operations. Conduct Reverse Engineering (disassemble, debug) on collected files, determine functionality and methods to successfully execute files.

Tools/Techniques: Ghidra, IDA, and GDB.

Scenario Credentials: FLAG = R3V3R535t@rt0F@ct1v1ty

Prior Approvals:All files can be extracted from the known target "Donovian-Webserver". Only authorized to conduct task on Analyst Workstations.

T1
Hostname: web.site.donovia
IP: 192.168.28.111
OS: unknown
Creds: comrade::StudentWebExploitPassword
Last Known SSH Port: unknown
PSP: Unknown
Malware: Unknown
Action: Extract approved binaries under directory titled "longTermStorage".
```


### Assembly

```
RAX/EAX
2
Level I Challenge
What is %RAX and %EAX main purpose?

 Their purpose is to hold the memory address of the top of the stack
 %RAX/%EAX are not valid x86-64 registers
 They are the first return registers for x86-64 and x86 Correct
 These registers act as breakpoints when debugging a process
```

```
RIP/EIP
2
Level I Challenge
What is %RIP and %EIP main purpose?

 They are the first return registers for x86-64 and x86
 %RIP/%EIP are the 64 bit and 32 bit instruction pointers that hold the memory address to the next instruction Correct
 %RIP/%EIP are not valid x86-64 registers
 Their purpose is to keep track of the top of the stack
```

```
RBP/EBP
2
Level I Challenge
What is %RBP and %EBP main purpose?

 %RBP/%EBP keep track of the top of the stack
 They are the 64 bit and 32 bit stack base pointers Correct
 These registers act as breakpoints when debugging a process
 The purpose of these registers is to perform extended floating point math
```

```
R8
2
Level I Challenge
What is %R8 size in bits? 64
```

```
Register Size
2
Level I Challenge
Which of these registers has a size of 32 bits?

 %RAX
 %AX
 %R12D Correct
 %R15W
```

```
JE
2
Level I Challenge
What register does the JE instruction rely upon? Flag
```

```
JE 2
2
Level I Challenge
What flag does the JE instruction rely upon?

 Parity Flag
 Zero Flag Correct
 Sign Flag
 Carry Flag
```

```
CMP
2
Level I Challenge
What does the CMP instruction do?

 Move source to destination
 Pushes the source onto the stack
 Jump to specified location
 Compares 2 values via subtraction Correct
```

```
ASM Flow 1
2
Level I Challenge

Main:
   Mov R8, 25
   Push R8
   Mov R10, 50
   Push R10
   Pop RAX

What value is on the top of the stack? 25
```

```
ASM Flow 2
2
Level I Challenge

Main:
   Mov R8, 25
   Push R8
   Mov R10, 50
   Push R10
   Pop RAX

What value is in the return register? 50
```

```
ASM Flow 3
2
Level I Challenge

Main:
    Mov R9, 5
    Mov R10, 20
    Add R10, R9
    CMP R10, R9
    JE Clean
    Mov RAX, 14
    ret

Clean:
    Mov RAX, 0
    ret

What value is returned? 14
```

### C Source Code

```
printf()
2
Level I Challenge
What does the printf() function do?

 It prints a file on the default printer
 It sends formatted output to standard out (E.g. the terminal) Correct
 It reads a line from the specified stream and stores it into a character array
 It compares two strings (character arrays)
```

```
fgets()
2
Level I Challenge
What does the fgets() function do?

 It reads a line from the specified stream and stores it into a character array Correct
 It gets a file uploaded to a deployed web server
 It ensures that the program stack is properly aligned
 It gets files pointed to by the program
```

```
strcmp()
2
Level I Challenge
What does the strcmp() function do?

 It breaks each argument down into hex and returns the output
 It reads a line from the specified stream and stores it into a character array
 It sends formatted output to standard out (E.g. the terminal)
 It compares two strings (character arrays) Correct
```

```
strcmp() 2
2
Level I Challenge
What is a successful return code for the strcmp() function if the two strings are the same? 0
```

```
main()
2
Level I Challenge
What is main()?

 It is the designated entry point to a program Correct
 It’s only role is to perform the majority of encryption operations for all Windows programs
 Main() is not a standard function in C
```

```
C Source Code 1
2
Level I Challenge

int main(void){
       int num1 = 77;
       printf("%d",num1);
       return 0;
}
What is num1’s variable type? int
```

```
C Source Code 2
2
Level I Challenge

int main(void){
       int num1 = 77;
       printf("%d",num1);
       return 0;
}
What is num1’s value? 77
```

```
C Source Code 3
5
Level II Challenge

int main(void){
       int num1 = 77;
       printf("%d",num1);
       return 0;
}
What value is printed to the terminal upon execution? 77
```

```
C Source Code 4
5
Level II Challenge

int main(void){
       int num1 = 77;
       printf("%d",num1);
       return 0;
}
What is “%d” in this program?

 %d stands for deviation and acts a place holder for printing standard deviation within a dataset
 %d is a placeholder for day and parses the "day" out of a provided date
 %d is a digit placeholder within printf() Correct
```

```
C Source Code 5
5
Level II Challenge

int main(void){
       int num1 = 77;
       printf("%d",num1);
       return 0;
}
What is important about “return 0”?

 A return code of 0 is generally a clean exit of the program Correct
 A return code of 0 is the default exit code for a program exiting under catastrophic failure
 A return code of 0 means that the program ran incorrectly and nothing happened during it execution
```

```
C Source Code 6
5
Level II Challenge

int main(void){
     char word1[4] = “word”;
     char word2[5] = “words”;
     if(strcmp(word1,word2)==0){
     printf(“same”);
  }
  else{
     printf(“different”);
  }
}
What is returned to stdout when executed? different
```

### Binary Analysis

```
Entry.exe
5
Level II Challenge
Situation:
Various teams have extracted binaries from Donovian development networks. Analyze the given binaries to find weaknesses and create signatures.

Provided:
compiled executable: (entry.exe)
source code: (entry.c)
Task: Run the executable with expected input and retrieve success message.
Method: disassemble the executable and follow the program’s execution to discover its functionality, and expected input.

Ensure that before you move on from this challenge that you have fully understood what you have done to disassemble and reverse engineer this binary and how it is related to the provided source code.

What is the key for this binary?

123@magicKey
```

```
Basic Algorithm
5
Level II Challenge
Situation:
Various teams have extracted binaries from Donovian development networks. Analyze the given binaries to find weaknesses and create signatures.

Provided:
compiled executable: (basic1.exe)
Task: Run the executable and retrieve a successful message using the binary's key.
Method: disassemble the executable and follow the program’s execution to discover its functionality, and expected input.

Add the value of all of the keys together. What is the MD5 hash of this sum?
46 92

79bc18f6cbd3b2290cbd69c190d62bc6
```

```
Software Doing Software Things 1
8
Level III Challenge
Situation:
Various teams have extracted binaries from Donovian development networks. Analyze the given binaries to find weaknesses and create signatures.

Provided:
compiled executable: (sdst.exe)
Task: Run the executable with expected input and retrieve success message.
Method: disassemble the executable and follow the program’s execution to discover its functionality, and expected input.

What is the MD5 hash of the key (specifically the value and not location) that the program required?

17535-8011=9524

4c8b12c6485fc0b4ebae47a30f49ca0c
```

```
Software Doing Software Things 2
8
Level III Challenge
Situation:
Various teams have extracted binaries from Donovian development networks. Analyze the given binaries to find weaknesses and create signatures.

Provided:
compiled executable: (sdst2.exe)
Task: Run the executable with expected input and retrieve success message.
Method: disassemble the executable and follow the program’s execution to discover its functionality, and expected input.

Show the instructor how you solved this to be awarded points.
put the same item in registry and file after the program is ran
```


```
Software Doing Software Things 3 - Part 1
8
Level III Challenge
Situation:

Various teams have extracted binaries from Donovian development networks. Analyze the given binaries to find weaknesses and create signatures. Provided:
compiled executable: (sdst3.exe)
Task: Run the executable with expected input and retrieve success message.
Method: disassemble the executable and follow the program’s execution to discover its functionality, and expected input.

What value determines successful execution of the binary?

18765
```

```
Software Doing Software Things 3 - Part 2
5
Level II Challenge
Provided:
compiled executable: (sdst3.exe)
Task: Run the executable with expected input and retrieve success message.
Method: disassemble the executable and follow the program’s execution to discover its functionality, and expected input.

Enter the complete name of one of the items used to determine the success of the binary's execution.

/tmp/key
```


```
PE Patching
8
Level III Challenge
Situation:
Various teams have extracted binaries from Donovian development networks. Analyze the given binaries to find weaknesses and create signatures.

Provided:
compiled executable: (patching.exe)
Task: Provide a patched executable that displays a "Successful" message for every key entered
Method: Utilize RE toolset provided to patch additional or modified functionality to the binary.

Use your imagination to show the patched file to the instructor and they will give you the points if you have completed the challenge successfully
```

```
Encrypted Payload 1
9
Level III Challenge
Situation:
Various teams have extracted binaries from Donovian development networks. Analyze the given binaries to find weaknesses and create signatures.

Provided:
compiled executable: (controller4.exe)
Task: Provide the symmetric key used during decryption of the payload in ASCII.
Method: Utilize RE toolset to reverse engineer the given binary finding where and how the symmetric key is used.

Submit the symmetric key as the flag.
```
