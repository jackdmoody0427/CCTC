## Security Day 1 *(Dec 15, 2021)* **(Security Basics)**

### Penetration Testing

[Penetration Testing Slides](https://sec.cybbh.io/-/public/-/jobs/579821/artifacts/slides/01-pentesting-overview.html)

---
### Today's plan
  - [X] Intros
  - [X] CTFd Orientation
  - [X] Penetration Testing Slides
---

#### Rationale

Penetration tests provide a relatable methodology that promotes critical thought and technical problem solving in all aspects of the Cyber domain. It promotes these things because the fundamental technical problems and tactics in a pentration test are nearly identical to offensive and defensive operations. Penetration testers and offensive operators use these skills, tactics, and knowledge to quietly exploit and pivot throughout a network. Defenders use these skills, tactics, and knowledge to prevent/detect/recover from intrusions, verify host integrity, and find/fix bugs in software and systems.

####  Penetration Test

1. PHASE 1: MISSION DEFINITION
   - Define mission goals and targets.
   - Determine scope of mission.
   - Define RoE.


2. PHASE 2: RECON
   - Information gathering about the target through public sources.


3. PHASE 3: FOOTPRINTING
   - Accumulate data through scanning and/or interaction with the target/target resources.


4. PHASE 4: EXPLOITATION & INITIAL ACCESS
   - Gain initial foothold on network


5. PHASE 5: POST-EXPLOITATION
   - Establish persistence
   - Escalate privileges
   - Cover your tracks
   - Exfiltrate target data


6. PHASE 6: DOCUMENT MISSION
   - Document and report mission details


#### PENETRATION TEST REPORTING

* Operation Notes vs Formalized Reporting
* Executive Summary
* Technical Summary
* Reasons to report
* What to report
* Screen Captures
