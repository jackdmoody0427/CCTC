## Reconnaissance Challanges

```
SITREP:Your team has been deployed for Operation Golden Nugget, in direct support of Gorgas forces amid the Donovian-Gorgas war. You have been tasked to collect, analyze, and process data utilizing various reconnaissance techniques throughout Donovian and Gorgas Cyberspace.

Maintain 'low visibility' on the wire, as security products may be in place, and document your actions and results as you will be expected to provide OpNotes upon request.

Intelligence believes that not all of the 192.168.28.96/27 network has the ability to communicate with the 192.168.150.224/27 network.

Donovian Reconnaissance and Scanning (DR&S)
XX June 2024
Start Time: 1300
Duration: 4 hours

Type of Operation: Cyber Intelligence, Surveillance and Reconnaissance (C-ISR)

Objective:Scan target networks to gather pertinent host information.

Tools/Techniques: All connections will be established through network scans or web browser. Ports in use will be dependent on target location and are subject to change. Network scanning tools/techniques are limited to NSE scripts, python lxml and OSINT.

Scenario Credentials: FLAG = R3C0N5t@rt0F@ct1v1ty

Prior Approvals: OSINT through publicly available resources. Scrape appropriate web content that will provide operational data. Testing of found credentials. NOT approved to change routing, passwords, services, destroy data, upload of tools, create accounts

Scheme of Maneuver:
>internet_grey_host
->Network scan: 192.168.28.96/27
->Network scan:192.168.150.224/27

Target Section:

Network scans:
Network: 192.168.28.96/27
Network:192.168.150.224/27
OSs: unknown
Creds: student ::
Known Ports: unknown
Known URL: consulting.site.donovia
Known URL: conference.site.donovia
Action: Reconnaissance to collect intelligence and identify possible avenues of approach in the network.
```

```
# Code used
for i in {97..126} ;do (ping -c 1 192.168.28.$i | grep "bytes from" &) ;done
for i in {225..254} ;do (ping -c 1 192.168.150.$i | grep "bytes from" &) ;done

```

```
FTP
5
Level II Challenge
File Transfer Protocol (FTP) appears to be available within Donovian Cyberspace, perform further reconnaissance and interrogate this service to identify the flag.

proxychains nmap -sT -p 21 192.168.28.105
student@lin:~/192.168.28.105$ wget -r ftp://192.168.28.105
cat ghGbEfql1sEpXHRcJ8qJ
```


```
Key Speaker
5
Level II Challenge
Intelligence shows that the Donovian Government is preparing for a conference, you have been tasked to collect all information relating to the speakers.

Identify the key individual to find the FLAG



something: 1o5ibx5EeNyn567Ck44I
```

7Yr5C,jVNi0,HuHWn,th3Fifth@,wS6ya
7Yr5CjVNi0HuHWnwS6ya
7Yr5C,HuHWn,wS6ya,jVNi0
7Yr5CHuHWnwS6yajVNi0



```
Company Article
5
Level II Challenge
A company has posted an article to Donovian Consulting Groups blog, Identify the flag associated with the company.
FLAG: 1o5ibx5EeNyn567Ck44I # search org-title
```

```
SMB
5
Level II Challenge
Your team has received intelligence related to Server Message Block being available. Identify the host and associated flag.

proxychains nmap 192.168.28.1111 --script smb-os-discovery -Pn

FLAG:


PassTemporary
loginfirst
logout null bit
houseBeatFliesLOW
YourTempPassword


ssh student@10.50.42.163 -L 42301:localhost:22 -NT
ssh student@localhost -p 42301 -L 42302:192.168.28.120:4242 -NT
ssh student@localhost -p 42302 -D 9050 -NT
student@grey:~$ for i in {200..254} ;do (ping -c 1 192.168.150.$i | grep "bytes from" &) ;done
student@linux-opstation-ebhy:~$ proxychains nmap 192.168.150.245 -T5 -Pn -p- --min-rate 8000 2>/dev/null
student@linux-opstation-ebhy:~$ proxychains nmap -Pn 192.168.150.245 --script smb-os-discovery.nse
FLAG: 'jPjDQxt1BIVW7RovLrB7'
```

```
TITLE tags
5
Level II Challenge
Find the Titles of all the hosted web servers, identify which one has the flag.
FLAG: k4Uouq8gCgCquG9gQ7A0
```
