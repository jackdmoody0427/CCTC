## Security Day 4 *(Jan 5, 2022)* **(Reverse Engineering)**

### Reverse Engineering

[Reverse Engineering Slides](https://sec.cybbh.io/-/public/-/jobs/643395/artifacts/slides/06-reverse-engineering.html)

[Reverse Engineering Field Guide](https://sec.cybbh.io/public/security/latest/lessons/lesson-6-reverse_sg.html)

---
### Today's plan
  - [X] CTFd Orientation
  - [X] Reverse Engineering Slides
  - [X] CTF's

---

#### Rationale

Reverse engineering is a fundamental skill at the base of all exploitation and defense. It is a term that is often misunderstood in a way that implies reverse engineering only occurs on malicious executable binaries programmed in a compiled language like C. Reverse engineering is far more encompassing than this. Whenever a Cyber actor interacts with or takes something apart to learn about how it works, they are performing reverse engineering. It is that simple. All exploitation and defense is based on taking things apart and understanding how they work whether that be with an electron microscope, an x86 disassembler, interaction with the object, or through reading the manual/source code. Reverse engineering is performed on software, hardware, network/signal protocols, and just about anything another human has created. It is performed with the aim of understanding something better to achieve the goals of an individual or organization.

#### X86_64 Assembly

There are 16 general purpose 64 bit registers

```
%rax -> the first return register

%rbp -> the base pointer that keeps track of the base of the stack

%rsp -> the stack pointer that points to the top of the stack

You will see arguments passed to functions as something like:
[%ebp-0x8]

```

X86_64_guide.pdf

#### X86_64 Assembly - Common Terms

```
Heap -> Memory that can be allocated and deallocated

Stack -> A contiguous section of memory used for passing arguments

General Register -> A multipurpose register that can be used by either programmer or user to store data or a memory location address

Control Register -> A processor register that changes or controls the behavior of a CPU

Flags Register -> Contains the current state of the processor
```

#### X86_64 Assembly - Memory Offset

There is one instruction pointer register that points to the memory offset of the next instruction in the code segment

```
64-bit | lower 32 bits | lower 16 bits | Descrition

RIP | EIP | IP | Instruction Pointer; holds address for next instruction to be executed
```

#### X86_64 Assembly Common Instruction Pointers

```
MOV -> move source to destination

PUSH -> push source onto stack

POP -> Pop top of stack to destination

INC -> Increment source by 1

DEC -> Decrement source by 1

ADD -> Add source to destination

SUB -> Subtract source from destination

CMP -> Compare 2 values by subtracting them and setting the %RFLAGS register. ZeroFlag set means they are the same.

JMP -> Jump to specified location

JLE -> Jump if less than or equal

JE -> Jump if equal
```

#### Reverse Engineering Workflow (Software)

* Static
* Behavioral
* Dynamic
* Disassembly
* Document Findings

Reverse_engineering_workflow.pdf

#### Portable Executable Patching / Software Analysis

* Perform Debugging and Disassembly
* Find the Success/Failure
* Adjust Instructions
* Apply Patch and Save
* Execute Patched Binary


## Security Day 5 *(Jan 6, 2022)* **(Reverse Engineering Continued)**

#### IDA

Drag file onto Ida to start it.

#### GHIDRA

Wait to do anything until it finishes analyzing
