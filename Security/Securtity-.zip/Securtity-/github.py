import os
import sys
from datetime import datetime


def compare_time(current_time):
    now = datetime.now()
    tz0 = now.replace(hour=0, minute=0, second=0, microsecond=0)
    tz1 = now.replace(hour=3, minute=0, second=0, microsecond=0)
    tz2 = now.replace(hour=6, minute=0, second=0, microsecond=0)
    tz3 = now.replace(hour=9, minute=0, second=0, microsecond=0)
    tz4 = now.replace(hour=11, minute=0, second=0, microsecond=0)
    tz5 = now.replace(hour=13, minute=0, second=0, microsecond=0)
    tz6 = now.replace(hour=15, minute=0, second=0, microsecond=0)
    tz7 = now.replace(hour=18, minute=0, second=0, microsecond=0)
    tz8 = now.replace(hour=20, minute=0, second=0, microsecond=0)
    tz9 = now.replace(hour=23, minute=59, second=59, microsecond=0)

    if tz0 <= current_time <= tz1:
        return "Early Morning/Late Night Update"
    elif tz1 <= current_time <= tz2:
        return "Early Morning Update"
    elif tz2 <= current_time <= tz3:
        return "Breakfast Update"
    elif tz3 <= current_time <= tz4:
        return "Morning Update"
    elif tz4 <= current_time <= tz5:
        return "Lunch Update"
    elif tz5 <= current_time <= tz6:
        return "Early Afternoon Update"
    elif tz6 <= current_time <= tz7:
        return "Late Afternoon Update"
    elif tz7 <= current_time <= tz8:
        return "Dinner Update"
    elif tz8 <= current_time <= tz9:
        return "Late Night Update"
    else:
        raise Exception


def check_time():
    now = datetime.now()
    try:
        comment = compare_time(now)
        if isinstance(comment, str):  # Look at this
            return comment

    except Exception as err:
        print("Time error", err)
        return "Update"


def pull():
    os.system("git pull")


def push():
    update = check_time()
    commit = 'git commit -m "{}"'.format(update)
    os.system('git add .')
    os.system(commit)
    os.system("git push")


def status():
    os.system("git status")


def decision1():
    argument_list = sys.argv[1:]

    if len(argument_list) == 0:
        print("Please enter an argument!\nPlease use '-h' for a list of valid commands.")

    help_user = ["-h", "-help", "--help"]
    valid_commands = ["-pull", "-push", "-status"] + help_user

    for arg in argument_list:
        if arg == "-pull":
            pull()
        elif arg == "-push":
            push()
        elif arg == "-status":
            status()
        elif arg in help_user:
            print("Valid decisions are:", valid_commands)
        else:
            raise Exception


def main():
    try:
        decision1()
    except Exception as error:
        print("Invalid Command! Please use '-h' for a list of valid commands.", error)


main()
